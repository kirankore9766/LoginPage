## 0.2.23（2021-05-27）
- 升级uni-id到3.1.0版本，默认对邮箱、用户名忽略大小写 [详情](https://uniapp.dcloud.net.cn/uniCloud/uni-id?id=case-sensitive)
## 0.2.22（2021-04-13）
- 升级uni-id到3.0.12版本，去除bindTokenToDevice配置
## 0.2.21（2021-04-13）
- 发布测试
## 0.2.20（2021-03-02）
- 修复user-center云函数中从上下文读取数据错误 
- 部分uni-ui插件改为uni_modules引入
## 0.2.19（2021-03-01）
- 调整为uni_modules目录规范
